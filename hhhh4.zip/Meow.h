#include "Constant.h"
#include "DoubleOperator.h"
#include "SingleOperator.h"
#include "Variable.h"
#include "Tensor.h"
#include "Placeholder.h"

